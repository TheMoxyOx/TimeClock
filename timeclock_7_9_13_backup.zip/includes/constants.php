<?php

// Define constants here

define('DB_SERVER', 'localhost');
define('DB_USER', 'admin_dev');
define('DB_PASSWORD', 'Cookies123');
define('DB_NAME', 'admin_dev');