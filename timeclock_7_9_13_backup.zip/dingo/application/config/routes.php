<?php if(!defined('DINGO')){die('External Access to File Denied');}


// Default Route
$route['default_route'] = 'main';

//$route['one/([a-zA-Z]+)/([a-zA-Z]+)'] = 'query/$1/$2';