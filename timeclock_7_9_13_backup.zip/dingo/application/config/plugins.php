<?php if(!defined('DINGO')){die('External Access to File Denied');}


// Plugin 'myplugin' can be accessed at URLs starting with 'pluginpage'
//$plugin['pluginpage'] = 'myplugin';
