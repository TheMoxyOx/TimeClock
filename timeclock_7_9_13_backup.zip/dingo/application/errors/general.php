<html>
<head>
	<title>Error - <?php echo $title; ?></title>
</head>
<body>
	<h1>Error - <?php echo $title; ?></h1>
	<p><?php echo $message; ?></p>
</body>
</html>