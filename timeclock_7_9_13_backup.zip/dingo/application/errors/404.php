<?php header('HTTP/1.1 404 Not Found'); ?>
<html>
<head>
	<title>404 Error - Page not found</title>
</head>
<body>
	<h1>404 Error</h1>
	<p>The requested page could not be found.</p>
</body>
</html>