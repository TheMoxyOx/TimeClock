<?php

$this->message->hello = 'Hello, World!';
$this->message->fox = 'The quick brown fox jumps over the lazy dog.';